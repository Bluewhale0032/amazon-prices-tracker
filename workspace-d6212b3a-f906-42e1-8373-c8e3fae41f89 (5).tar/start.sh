#!/bin/bash
# Amazon ↔ TikTok Sync Dashboard - Start Script
echo "🚀 Starting Amazon ↔ TikTok Sync Dashboard..."
cd /home/z/my-project

# Kill existing server
pkill -f "next dev" 2>/dev/null
sleep 1

# Start dev server
npx next dev -p 3000
