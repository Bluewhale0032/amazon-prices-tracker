#!/bin/bash
# Amazon ↔ TikTok Sync Dashboard - Production Start
echo "🚀 Starting Amazon ↔ TikTok Sync Dashboard (Production)..."
cd /home/z/my-project

# Kill existing server  
pkill -f "server.js" 2>/dev/null
sleep 1

# Build if needed
if [ ! -f ".next/standalone/server.js" ]; then
    echo "📦 Building production bundle..."
    npx next build
    cp -r .next/static .next/standalone/.next/
    cp -r public .next/standalone/
fi

# Start production server
NODE_ENV=production node .next/standalone/server.js
