# Project Brief: Amazon Price Monitoring & TikTok Shop Auto-Sync System

## Objective
Build an automated system that monitors Amazon product prices and stock status, updates a Google Sheet in real time, alerts the user when a price or stock change is detected, and provides a simple dashboard where the user can approve (or reject) syncing that change to their TikTok Shop listing.

---

## System Components

### 1. Google Sheet (Master Database)
Create a Google Sheet with these columns:

| Column | Description |
|---|---|
| Product Name | Name of the product |
| ASIN | Amazon Standard Identification Number |
| Original Amazon Price | Price when product was first listed |
| Current Amazon Price | Auto-updated live price |
| Price Change Status | UP / DOWN / NO CHANGE |
| TikTok Listing Price | Price currently live on TikTok Shop |
| Profit Margin (%) | Calculated automatically |
| Stock Status | IN STOCK / OUT OF STOCK |
| Last Updated | Timestamp of last check |
| Sync Status | PENDING / ACCEPTED / REJECTED / FAILED |
| Notes | Log of actions taken |

### 2. Amazon Price Monitoring
- Use the **Keepa API** (preferred) or a similar Amazon price-tracking API to check each ASIN's current price and stock status every 6–12 hours.
- Compare the new price against the last recorded price.
- If there is a change, update "Current Amazon Price," "Price Change Status," and "Stock Status" in the Google Sheet automatically.
- Recalculate the profit margin whenever the price changes.

### 3. Alert Dashboard
Build a simple web dashboard (can be a Google Apps Script Web App) that:
- Lists all products with a pending price or stock change.
- Shows old price vs. new price, and the new profit margin.
- Shows an "OUT OF STOCK" alert clearly when applicable.
- Has two buttons per alert: **Accept** and **Reject**.

Example alert text:
- "Product X price increased from $5 to $6. Profit margin dropped from 40% to 20%. Approve TikTok update?"
- "Product Y price decreased from $8 to $7. New profit margin: 35%. Approve TikTok update?"
- "Product Z is now OUT OF STOCK on Amazon. Set TikTok inventory to 0?"

### 4. TikTok Shop API Integration
- Integrate the **TikTok Shop Partner API (Open Platform)**.
- When the user clicks **Accept**:
  - Update the TikTok Shop listing price to match the new Amazon price plus the user's profit margin.
  - If out of stock, set TikTok inventory to 0.
  - If back in stock, restore inventory.
  - Log the action with a timestamp in the "Notes" column.
- When the user clicks **Reject**:
  - Do not change the TikTok listing.
  - Log the rejection with a timestamp.

### 5. Automation & Notifications
- Use Google Apps Script time-based triggers to run price checks every 6–12 hours.
- Send an email notification to the user whenever a price or stock change is detected.
- Dashboard should reflect new alerts as soon as they occur.

### 6. Error Handling & Logging
- Keep a separate "Logs" sheet recording every API call, update, and error.
- If the Keepa API call fails, email the user an alert.
- If the TikTok API update fails, mark the row as "FAILED" and notify the user.

---

## Technical Stack
- Google Sheets — data storage
- Google Apps Script — backend automation and logic
- Keepa API — Amazon price and stock data
- TikTok Shop Partner API — price/inventory sync
- Google Apps Script Web App — dashboard frontend

---

## Deliverables
1. Google Sheet template with all required columns and formulas.
2. Google Apps Script code for the Keepa API integration and price-check automation.
3. Dashboard web app (HTML/CSS/JS inside Apps Script) with Accept/Reject actions.
4. TikTok Shop API integration code for price and inventory updates.
5. Time-based trigger setup for automatic scheduled checks.
6. Short documentation explaining how to add API keys/credentials and how to use the dashboard.

---

## Requirements From Client (Me)
- I will provide the **Keepa API key**.
- I will provide **TikTok Shop Developer/Partner API credentials**.
- All TikTok price updates must include my profit margin calculation — never copy the Amazon price directly.
- Out-of-stock status must sync to TikTok as zero inventory automatically (no approval needed for this specific case, unless you recommend otherwise).
- Price changes (up or down) must always go through the Accept/Reject approval step before updating TikTok.
