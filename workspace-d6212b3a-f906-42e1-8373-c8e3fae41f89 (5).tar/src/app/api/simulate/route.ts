import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

// Simulate Keepa API check - randomly changes prices/stock for demo
export async function POST() {
  try {
    const products = await db.product.findMany()
    const results: string[] = []

    for (const product of products) {
      const rand = Math.random()

      if (rand < 0.4) {
        // Price change
        const changePercent = (Math.random() * 20 - 10) // -10% to +10%
        const oldPrice = product.currentAmazonPrice
        const newPrice = parseFloat((oldPrice * (1 + changePercent / 100)).toFixed(2))

        if (Math.abs(newPrice - oldPrice) < 0.01) continue

        const changeStatus = newPrice > oldPrice ? 'UP' : 'DOWN'
        const newMargin = ((product.tiktokListingPrice - newPrice) / newPrice * 100)
        const oldMargin = product.profitMargin

        await db.product.update({
          where: { id: product.id },
          data: {
            currentAmazonPrice: newPrice,
            priceChangeStatus: changeStatus,
            profitMargin: parseFloat(newMargin.toFixed(1)),
            syncStatus: 'PENDING',
            updatedAt: new Date(),
          },
        })

        await db.alert.create({
          data: {
            productId: product.id,
            alertType: changeStatus === 'UP' ? 'PRICE_UP' : 'PRICE_DOWN',
            oldValue: oldPrice,
            newValue: newPrice,
            oldMargin: parseFloat(oldMargin.toFixed(1)),
            newMargin: parseFloat(newMargin.toFixed(1)),
            message: `${product.name} price ${changeStatus === 'UP' ? 'increased' : 'decreased'} from $${oldPrice.toFixed(2)} to $${newPrice.toFixed(2)}. Margin: ${oldMargin.toFixed(1)}% → ${newMargin.toFixed(1)}%.`,
          },
        })

        results.push(`${product.name}: $${oldPrice.toFixed(2)} → $${newPrice.toFixed(2)} (${changeStatus})`)
      } else if (rand < 0.5 && product.stockStatus === 'IN STOCK') {
        // Go out of stock
        await db.product.update({
          where: { id: product.id },
          data: { stockStatus: 'OUT_OF_STOCK', syncStatus: 'PENDING', updatedAt: new Date() },
        })

        await db.alert.create({
          data: {
            productId: product.id,
            alertType: 'OUT_OF_STOCK',
            oldValue: 1,
            newValue: 0,
            message: `${product.name} is now OUT OF STOCK on Amazon.`,
          },
        })

        results.push(`${product.name}: OUT OF STOCK`)
      } else if (rand < 0.55 && product.stockStatus === 'OUT_OF_STOCK') {
        // Back in stock
        await db.product.update({
          where: { id: product.id },
          data: { stockStatus: 'IN STOCK', updatedAt: new Date() },
        })

        await db.alert.create({
          data: {
            productId: product.id,
            alertType: 'BACK_IN_STOCK',
            oldValue: 0,
            newValue: 1,
            message: `${product.name} is back IN STOCK on Amazon.`,
          },
        })

        results.push(`${product.name}: BACK IN STOCK`)
      }
    }

    await db.log.create({
      data: {
        action: 'API_CALL',
        detail: `Simulated Keepa price check. ${results.length} changes detected: ${results.join('; ') || 'None'}`,
        severity: 'INFO',
      },
    })

    return NextResponse.json({
      success: true,
      changesDetected: results.length,
      details: results,
    })
  } catch (error) {
    return NextResponse.json({ error: 'Simulation failed' }, { status: 500 })
  }
}
