import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function POST(request: Request) {
  try {
    const { alertId, action } = await request.json() // action = "ACCEPT" | "REJECT"

    const alert = await db.alert.findUnique({
      where: { id: alertId },
      include: { product: true },
    })

    if (!alert) {
      return NextResponse.json({ error: 'Alert not found' }, { status: 404 })
    }

    if (alert.status !== 'PENDING') {
      return NextResponse.json({ error: 'Alert already resolved' }, { status: 400 })
    }

    const product = alert.product

    if (action === 'ACCEPT') {
      // Calculate new TikTok price with profit margin
      const newTiktokPrice = product.currentAmazonPrice * (1 + product.profitMargin / 100)
      const isOutOfStock = alert.alertType === 'OUT_OF_STOCK'

      await db.product.update({
        where: { id: product.id },
        data: {
          tiktokListingPrice: isOutOfStock ? product.tiktokListingPrice : parseFloat(newTiktokPrice.toFixed(2)),
          syncStatus: isOutOfStock ? 'SYNCED' : 'SYNCED',
          priceChangeStatus: 'NO CHANGE',
          notes: `${new Date().toISOString()} - ${alert.alertType}: Accepted. ${isOutOfStock ? 'TikTok inventory set to 0.' : `TikTok price updated to $${newTiktokPrice.toFixed(2)}`}`,
          updatedAt: new Date(),
        },
      })

      await db.alert.update({
        where: { id: alertId },
        data: { status: 'ACCEPTED', resolvedAt: new Date() },
      })

      await db.log.create({
        data: {
          productId: product.id,
          action: 'SYNC',
          detail: `Accepted ${alert.alertType} for ${product.name}. TikTok ${isOutOfStock ? 'inventory → 0' : `price → $${newTiktokPrice.toFixed(2)}`}`,
          severity: 'INFO',
        },
      })

      return NextResponse.json({ success: true, message: 'Change accepted and synced to TikTok Shop' })
    } else {
      // REJECT
      await db.product.update({
        where: { id: product.id },
        data: {
          syncStatus: 'REJECTED',
          priceChangeStatus: 'NO CHANGE',
          notes: `${new Date().toISOString()} - ${alert.alertType}: Rejected by operator.`,
          updatedAt: new Date(),
        },
      })

      await db.alert.update({
        where: { id: alertId },
        data: { status: 'REJECTED', resolvedAt: new Date() },
      })

      await db.log.create({
        data: {
          productId: product.id,
          action: 'SYNC',
          detail: `Rejected ${alert.alertType} for ${product.name}. No changes made to TikTok.`,
          severity: 'WARNING',
        },
      })

      return NextResponse.json({ success: true, message: 'Change rejected. TikTok listing unchanged.' })
    }
  } catch (error) {
    return NextResponse.json({ error: 'Failed to process sync action' }, { status: 500 })
  }
}
