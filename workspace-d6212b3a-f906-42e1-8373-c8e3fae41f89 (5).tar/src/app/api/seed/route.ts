import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function POST() {
  try {
    // Delete existing data first for clean seed
    await db.alert.deleteMany()
    await db.log.deleteMany()
    await db.product.deleteMany()

    const sampleProducts = [
      { name: 'Wireless Bluetooth Earbuds', asin: 'B09V3KXJPB', price: 29.99, margin: 40 },
      { name: 'USB-C Fast Charging Cable 6ft', asin: 'B08T5TV2L7', price: 12.99, margin: 55 },
      { name: 'Portable Phone Stand', asin: 'B09KYPMV8R', price: 8.49, margin: 65 },
      { name: 'LED Desk Lamp with USB Port', asin: 'B0BR5N7GKS', price: 34.99, margin: 35 },
      { name: 'Silicone Kitchen Utensil Set', asin: 'B0BPF1WY5H', price: 24.99, margin: 45 },
      { name: 'Mini Portable Fan Rechargeable', asin: 'B0C1L3TFQM', price: 15.99, margin: 50 },
      { name: 'Resistance Bands Set', asin: 'B08R4BZ1Q5', price: 11.99, margin: 60 },
      { name: 'Stainless Steel Water Bottle', asin: 'B0BDH4RQ1C', price: 19.99, margin: 42 },
    ]

    const created = []
    for (const p of sampleProducts) {
      const tiktokPrice = p.price * (1 + p.margin / 100)
      const product = await db.product.create({
        data: {
          name: p.name,
          asin: p.asin,
          originalAmazonPrice: p.price,
          currentAmazonPrice: p.price,
          tiktokListingPrice: parseFloat(tiktokPrice.toFixed(2)),
          profitMargin: p.margin,
          priceChangeStatus: 'NO CHANGE',
          stockStatus: 'IN STOCK',
          syncStatus: 'SYNCED',
        },
      })
      created.push(product)
    }

    await db.log.create({
      data: {
        action: 'API_CALL',
        detail: `Seeded ${created.length} sample products into the database.`,
        severity: 'INFO',
      },
    })

    return NextResponse.json({ success: true, count: created.length })
  } catch (error) {
    return NextResponse.json({ error: 'Seed failed' }, { status: 500 })
  }
}
