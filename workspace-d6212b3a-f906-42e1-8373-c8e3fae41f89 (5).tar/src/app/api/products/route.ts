import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET() {
  try {
    const products = await db.product.findMany({
      orderBy: { updatedAt: 'desc' },
    })
    return NextResponse.json(products)
  } catch (error) {
    return NextResponse.json({ error: 'Failed to fetch products' }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { name, asin, originalAmazonPrice, profitMargin } = body

    const tiktokListingPrice = originalAmazonPrice * (1 + (profitMargin || 0.3) / 100)

    const product = await db.product.create({
      data: {
        name,
        asin,
        originalAmazonPrice: parseFloat(originalAmazonPrice),
        currentAmazonPrice: parseFloat(originalAmazonPrice),
        tiktokListingPrice: parseFloat(tiktokListingPrice.toFixed(2)),
        profitMargin: parseFloat(profitMargin) || 30,
        priceChangeStatus: 'NO CHANGE',
        stockStatus: 'IN STOCK',
        syncStatus: 'SYNCED',
      },
    })
    return NextResponse.json(product, { status: 201 })
  } catch (error: unknown) {
    const msg = error instanceof Error && error.message.includes('Unique') ? 'ASIN already exists' : 'Failed to create product'
    return NextResponse.json({ error: msg }, { status: 400 })
  }
}

export async function DELETE(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const id = searchParams.get('id')

    if (!id) {
      return NextResponse.json({ error: 'Product ID required' }, { status: 400 })
    }

    // Delete related alerts and logs first
    await db.alert.deleteMany({ where: { productId: id } })
    await db.log.deleteMany({ where: { productId: id } })
    await db.product.delete({ where: { id } })

    return NextResponse.json({ success: true })
  } catch (error) {
    return NextResponse.json({ error: 'Failed to delete product' }, { status: 500 })
  }
}
