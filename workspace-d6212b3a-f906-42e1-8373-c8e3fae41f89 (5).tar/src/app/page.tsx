'use client'

import { useState, useEffect, useCallback } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table'
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from '@/components/ui/alert-dialog'
import { ScrollArea } from '@/components/ui/scroll-area'
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger,
} from '@/components/ui/dialog'
import {
  TrendingUp, TrendingDown, PackageX, PackageCheck, RefreshCw,
  CheckCircle2, XCircle, AlertTriangle, Activity, Database, FileText,
  ShoppingCart, ArrowRight, Bell, Zap, Settings, Link2, Key, Sheet,
  Plus, ExternalLink, Info, ChevronRight, Trash2,
} from 'lucide-react'

interface Product {
  id: string
  name: string
  asin: string
  originalAmazonPrice: number
  currentAmazonPrice: number
  priceChangeStatus: string
  tiktokListingPrice: number
  profitMargin: number
  stockStatus: string
  lastUpdated: string
  syncStatus: string
  notes: string
}

interface Alert {
  id: string
  productId: string
  alertType: string
  oldValue: number
  newValue: number
  oldMargin?: number
  newMargin?: number
  message: string
  status: string
  createdAt: string
  product: Product
}

interface LogEntry {
  id: string
  productId: string | null
  action: string
  detail: string
  severity: string
  createdAt: string
  product?: { name: string; asin: string }
}

export default function Dashboard() {
  const [products, setProducts] = useState<Product[]>([])
  const [alerts, setAlerts] = useState<Alert[]>([])
  const [logs, setLogs] = useState<LogEntry[]>([])
  const [loading, setLoading] = useState(true)
  const [simulating, setSimulating] = useState(false)
  const [seeding, setSeeding] = useState(false)
  const [selectedAlert, setSelectedAlert] = useState<Alert | null>(null)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [dialogAction, setDialogAction] = useState<'ACCEPT' | 'REJECT'>('ACCEPT')
  const [activeTab, setActiveTab] = useState('dashboard')

  // Setup state
  const [keepaApiKey, setKeepaApiKey] = useState('')
  const [tiktokShopKey, setTiktokShopKey] = useState('')
  const [tiktokShopSecret, setTiktokShopSecret] = useState('')
  const [googleSheetUrl, setGoogleSheetUrl] = useState('')
  const [newProductName, setNewProductName] = useState('')
  const [newProductAsin, setNewProductAsin] = useState('')
  const [newProductPrice, setNewProductPrice] = useState('')
  const [newProductMargin, setNewProductMargin] = useState('30')
  const [addingProduct, setAddingProduct] = useState(false)
  const [addProductOpen, setAddProductOpen] = useState(false)
  const [savedSettings, setSavedSettings] = useState(false)

  const fetchData = useCallback(async () => {
    try {
      const [pRes, aRes, lRes] = await Promise.all([
        fetch('/api/products'),
        fetch('/api/alerts'),
        fetch('/api/logs'),
      ])
      setProducts(await pRes.json())
      setAlerts(await aRes.json())
      setLogs(await lRes.json())
    } catch (err) {
      console.error('Fetch error:', err)
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    fetchData()
    // Load saved settings from localStorage
    const saved = localStorage.getItem('sync-settings')
    if (saved) {
      const s = JSON.parse(saved)
      setKeepaApiKey(s.keepaApiKey || '')
      setTiktokShopKey(s.tiktokShopKey || '')
      setTiktokShopSecret(s.tiktokShopSecret || '')
      setGoogleSheetUrl(s.googleSheetUrl || '')
    }
  }, [fetchData])

  const saveSettings = () => {
    localStorage.setItem('sync-settings', JSON.stringify({ keepaApiKey, tiktokShopKey, tiktokShopSecret, googleSheetUrl }))
    setSavedSettings(true)
    setTimeout(() => setSavedSettings(false), 2000)
  }

  const handleSeed = async () => {
    setSeeding(true)
    await fetch('/api/seed', { method: 'POST' })
    await fetchData()
    setSeeding(false)
  }

  const handleSimulate = async () => {
    setSimulating(true)
    await fetch('/api/simulate', { method: 'POST' })
    await fetchData()
    setSimulating(false)
  }

  const handleSync = async (alertId: string, action: 'ACCEPT' | 'REJECT') => {
    await fetch('/api/sync', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ alertId, action }),
    })
    setDialogOpen(false)
    setSelectedAlert(null)
    await fetchData()
  }

  const handleAddProduct = async () => {
    if (!newProductName || !newProductAsin || !newProductPrice) return
    setAddingProduct(true)
    await fetch('/api/products', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        name: newProductName,
        asin: newProductAsin,
        originalAmazonPrice: newProductPrice,
        profitMargin: newProductMargin || '30',
      }),
    })
    setNewProductName('')
    setNewProductAsin('')
    setNewProductPrice('')
    setNewProductMargin('30')
    setAddProductOpen(false)
    setAddingProduct(false)
    await fetchData()
  }

  const handleDeleteProduct = async (id: string) => {
    await fetch(`/api/products?id=${id}`, { method: 'DELETE' })
    await fetchData()
  }

  const openDialog = (alert: Alert, action: 'ACCEPT' | 'REJECT') => {
    setSelectedAlert(alert)
    setDialogAction(action)
    setDialogOpen(true)
  }

  const getStatusBadge = (status: string) => {
    const variants: Record<string, { className: string; icon: React.ReactNode }> = {
      'PENDING': { className: 'bg-amber-100 text-amber-800 hover:bg-amber-100', icon: <AlertTriangle className="w-3 h-3 mr-1" /> },
      'SYNCED': { className: 'bg-emerald-100 text-emerald-800 hover:bg-emerald-100', icon: <CheckCircle2 className="w-3 h-3 mr-1" /> },
      'REJECTED': { className: 'bg-red-100 text-red-800 hover:bg-red-100', icon: <XCircle className="w-3 h-3 mr-1" /> },
      'FAILED': { className: 'bg-red-100 text-red-800 hover:bg-red-100', icon: <XCircle className="w-3 h-3 mr-1" /> },
    }
    const v = variants[status] || variants['PENDING']
    return <Badge variant="outline" className={`flex items-center text-xs font-medium ${v.className}`}>{v.icon}{status}</Badge>
  }

  const getAlertBadge = (type: string) => {
    const variants: Record<string, { className: string; icon: React.ReactNode; label: string }> = {
      'PRICE_UP': { className: 'bg-red-100 text-red-800 hover:bg-red-100', icon: <TrendingUp className="w-3 h-3 mr-1" />, label: 'Price Up' },
      'PRICE_DOWN': { className: 'bg-emerald-100 text-emerald-800 hover:bg-emerald-100', icon: <TrendingDown className="w-3 h-3 mr-1" />, label: 'Price Down' },
      'OUT_OF_STOCK': { className: 'bg-red-100 text-red-800 hover:bg-red-100', icon: <PackageX className="w-3 h-3 mr-1" />, label: 'Out of Stock' },
      'BACK_IN_STOCK': { className: 'bg-emerald-100 text-emerald-800 hover:bg-emerald-100', icon: <PackageCheck className="w-3 h-3 mr-1" />, label: 'Back in Stock' },
    }
    const v = variants[type] || { className: 'bg-gray-100 text-gray-800', icon: null, label: type }
    return <Badge variant="outline" className={`flex items-center text-xs font-medium ${v.className}`}>{v.icon}{v.label}</Badge>
  }

  const getSeverityBadge = (severity: string) => {
    const cls = severity === 'ERROR' ? 'bg-red-100 text-red-800 hover:bg-red-100'
      : severity === 'WARNING' ? 'bg-amber-100 text-amber-800 hover:bg-amber-100'
      : 'bg-sky-100 text-sky-800 hover:bg-sky-100'
    return <Badge variant="outline" className={`text-xs font-medium ${cls}`}>{severity}</Badge>
  }

  // Stats
  const totalProducts = products.length
  const pendingAlerts = alerts.length
  const outOfStock = products.filter(p => p.stockStatus === 'OUT_OF_STOCK').length
  const syncedProducts = products.filter(p => p.syncStatus === 'SYNCED').length
  const pendingSync = products.filter(p => p.syncStatus === 'PENDING').length

  const isSetupComplete = keepaApiKey && tiktokShopKey

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <div className="flex flex-col items-center gap-3">
          <RefreshCw className="w-8 h-8 animate-spin text-slate-400" />
          <p className="text-slate-500 text-sm">Loading dashboard...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 bg-slate-900 rounded-lg flex items-center justify-center">
              <ShoppingCart className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="text-lg font-bold text-slate-900 leading-tight">Amazon ↔ TikTok Sync</h1>
              <p className="text-xs text-slate-500">Price Monitoring & Auto-Sync Dashboard</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" onClick={handleSimulate} disabled={simulating || totalProducts === 0}>
              <Zap className="w-4 h-4 mr-1" />
              {simulating ? 'Checking...' : 'Simulate Price Check'}
            </Button>
            <Button size="sm" onClick={handleSeed} disabled={seeding || totalProducts > 0}>
              <Database className="w-4 h-4 mr-1" />
              {seeding ? 'Seeding...' : 'Load Demo Data'}
            </Button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 py-6">
        {/* Stats Row */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-6">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-2 text-slate-500 text-xs mb-1"><PackageCheck className="w-4 h-4" /> Products</div>
              <div className="text-2xl font-bold text-slate-900">{totalProducts}</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-2 text-amber-600 text-xs mb-1"><Bell className="w-4 h-4" /> Pending Alerts</div>
              <div className="text-2xl font-bold text-amber-600">{pendingAlerts}</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-2 text-red-600 text-xs mb-1"><PackageX className="w-4 h-4" /> Out of Stock</div>
              <div className="text-2xl font-bold text-red-600">{outOfStock}</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-2 text-emerald-600 text-xs mb-1"><CheckCircle2 className="w-4 h-4" /> Synced</div>
              <div className="text-2xl font-bold text-emerald-600">{syncedProducts}</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-2 text-amber-600 text-xs mb-1"><AlertTriangle className="w-4 h-4" /> Pending Sync</div>
              <div className="text-2xl font-bold text-amber-600">{pendingSync}</div>
            </CardContent>
          </Card>
        </div>

        {/* Setup Banner - shows when not configured */}
        {!isSetupComplete && (
          <Card className="mb-6 border-amber-200 bg-amber-50">
            <CardContent className="p-4 flex items-center gap-3">
              <Info className="w-5 h-5 text-amber-600 flex-shrink-0" />
              <div className="flex-1">
                <p className="text-sm font-medium text-amber-800">Setup Incomplete — Connect your APIs to go live</p>
                <p className="text-xs text-amber-600 mt-0.5">Go to the <strong>Setup</strong> tab to add your Keepa API key and TikTok Shop credentials. Currently running in <strong>Demo Mode</strong> with simulated data.</p>
              </div>
              <Button size="sm" variant="outline" className="border-amber-300 text-amber-700 hover:bg-amber-100" onClick={() => setActiveTab('setup')}>
                Go to Setup <ChevronRight className="w-4 h-4 ml-1" />
              </Button>
            </CardContent>
          </Card>
        )}

        {/* Main Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="mb-4">
            <TabsTrigger value="dashboard" className="gap-1"><Activity className="w-4 h-4" /> Dashboard</TabsTrigger>
            <TabsTrigger value="alerts" className="gap-1 relative">
              <Bell className="w-4 h-4" /> Alerts
              {pendingAlerts > 0 && (
                <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 text-white text-xs rounded-full flex items-center justify-center">{pendingAlerts}</span>
              )}
            </TabsTrigger>
            <TabsTrigger value="products" className="gap-1"><ShoppingCart className="w-4 h-4" /> Products</TabsTrigger>
            <TabsTrigger value="setup" className="gap-1 relative">
              <Settings className="w-4 h-4" /> Setup
              {!isSetupComplete && <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-amber-500 rounded-full" />}
            </TabsTrigger>
            <TabsTrigger value="logs" className="gap-1"><FileText className="w-4 h-4" /> Logs</TabsTrigger>
          </TabsList>

          {/* ===== SETUP TAB ===== */}
          <TabsContent value="setup">
            <div className="space-y-6">

              {/* How It Works */}
              <Card className="border-slate-200">
                <CardHeader className="pb-4">
                  <CardTitle className="flex items-center gap-2 text-base"><Info className="w-5 h-5 text-slate-500" /> How This System Works</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid gap-4 md:grid-cols-4">
                    <div className="flex flex-col items-center text-center p-4 rounded-lg bg-slate-50">
                      <div className="w-10 h-10 bg-orange-100 rounded-full flex items-center justify-center mb-2"><span className="text-lg">1</span></div>
                      <h4 className="font-semibold text-sm mb-1">Amazon Products</h4>
                      <p className="text-xs text-slate-500">Add your Amazon product ASINs. The system will monitor their prices using the Keepa API.</p>
                    </div>
                    <div className="flex flex-col items-center text-center p-4 rounded-lg bg-slate-50">
                      <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center mb-2"><span className="text-lg">2</span></div>
                      <h4 className="font-semibold text-sm mb-1">Keepa API Checks</h4>
                      <p className="text-xs text-slate-500">Every 6-12 hours, Keepa fetches live prices & stock status. Changes create alerts in the dashboard.</p>
                    </div>
                    <div className="flex flex-col items-center text-center p-4 rounded-lg bg-slate-50">
                      <div className="w-10 h-10 bg-emerald-100 rounded-full flex items-center justify-center mb-2"><span className="text-lg">3</span></div>
                      <h4 className="font-semibold text-sm mb-1">Review & Approve</h4>
                      <p className="text-xs text-slate-500">When a price changes, you get an alert. Click Accept to sync to TikTok, or Reject to skip.</p>
                    </div>
                    <div className="flex flex-col items-center text-center p-4 rounded-lg bg-slate-50">
                      <div className="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center mb-2"><span className="text-lg">4</span></div>
                      <h4 className="font-semibold text-sm mb-1">TikTok Shop Sync</h4>
                      <p className="text-xs text-slate-500">Approved changes update your TikTok Shop listing price (Amazon price + your profit margin).</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* API Connections */}
              <div className="grid gap-6 md:grid-cols-2">

                {/* Keepa API */}
                <Card className={keepaApiKey ? 'border-emerald-200' : 'border-amber-200'}>
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-base flex items-center gap-2">
                        <div className="w-8 h-8 bg-orange-100 rounded-lg flex items-center justify-center"><Key className="w-4 h-4 text-orange-600" /></div>
                        Keepa API Key
                        {keepaApiKey ? <Badge className="bg-emerald-100 text-emerald-700 hover:bg-emerald-100 text-xs ml-2"><CheckCircle2 className="w-3 h-3 mr-1" />Connected</Badge> : <Badge className="bg-amber-100 text-amber-700 hover:bg-amber-100 text-xs ml-2">Required</Badge>}
                      </CardTitle>
                    </div>
                    <CardDescription>Used to fetch Amazon product prices and stock status</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="p-3 rounded-lg bg-slate-50 text-xs text-slate-600 space-y-1">
                      <p><strong>What it does:</strong> Keepa tracks Amazon prices in real-time. Your API key lets the system check prices every 6-12 hours.</p>
                      <p><strong>Get your key:</strong> Visit <a href="https://keepa.com/#!api" target="_blank" rel="noopener noreferrer" className="text-sky-600 underline inline-flex items-center gap-1">keepa.com/#!api <ExternalLink className="w-3 h-3" /></a></p>
                    </div>
                    <div className="space-y-1.5">
                      <Label htmlFor="keepa-key" className="text-xs font-medium">API Key</Label>
                      <Input id="keepa-key" type="password" placeholder="Enter your Keepa API key..." value={keepaApiKey} onChange={e => setKeepaApiKey(e.target.value)} />
                    </div>
                  </CardContent>
                </Card>

                {/* TikTok Shop API */}
                <Card className={tiktokShopKey ? 'border-emerald-200' : 'border-amber-200'}>
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-base flex items-center gap-2">
                        <div className="w-8 h-8 bg-purple-100 rounded-lg flex items-center justify-center"><Key className="w-4 h-4 text-purple-600" /></div>
                        TikTok Shop API
                        {tiktokShopKey ? <Badge className="bg-emerald-100 text-emerald-700 hover:bg-emerald-100 text-xs ml-2"><CheckCircle2 className="w-3 h-3 mr-1" />Connected</Badge> : <Badge className="bg-amber-100 text-amber-700 hover:bg-amber-100 text-xs ml-2">Required</Badge>}
                      </CardTitle>
                    </div>
                    <CardDescription>Used to update TikTok Shop listing prices and inventory</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="p-3 rounded-lg bg-slate-50 text-xs text-slate-600 space-y-1">
                      <p><strong>What it does:</strong> When you Accept an alert, the system updates your TikTok Shop product price via this API.</p>
                      <p><strong>Get credentials:</strong> Visit <a href="https://partner.tiktokshop.com/" target="_blank" rel="noopener noreferrer" className="text-sky-600 underline inline-flex items-center gap-1">partner.tiktokshop.com <ExternalLink className="w-3 h-3" /></a></p>
                    </div>
                    <div className="space-y-1.5">
                      <Label htmlFor="tt-key" className="text-xs font-medium">App Key / Client Key</Label>
                      <Input id="tt-key" type="password" placeholder="Enter TikTok Shop App Key..." value={tiktokShopKey} onChange={e => setTiktokShopKey(e.target.value)} />
                    </div>
                    <div className="space-y-1.5">
                      <Label htmlFor="tt-secret" className="text-xs font-medium">App Secret</Label>
                      <Input id="tt-secret" type="password" placeholder="Enter TikTok Shop App Secret..." value={tiktokShopSecret} onChange={e => setTiktokShopSecret(e.target.value)} />
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Google Sheet Connection */}
              <Card className={googleSheetUrl ? 'border-emerald-200' : 'border-slate-200'}>
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-base flex items-center gap-2">
                      <div className="w-8 h-8 bg-emerald-100 rounded-lg flex items-center justify-center"><Sheet className="w-4 h-4 text-emerald-600" /></div>
                      Google Sheet (Master Database)
                      {googleSheetUrl ? <Badge className="bg-emerald-100 text-emerald-700 hover:bg-emerald-100 text-xs ml-2"><CheckCircle2 className="w-3 h-3 mr-1" />Linked</Badge> : <Badge className="bg-slate-100 text-slate-600 hover:bg-slate-100 text-xs ml-2">Optional</Badge>}
                    </CardTitle>
                  </div>
                  <CardDescription>Link a Google Sheet to sync all product data in real-time (optional — the dashboard works independently)</CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="p-3 rounded-lg bg-slate-50 text-xs text-slate-600 space-y-1">
                    <p><strong>What it does:</strong> All product data (prices, margins, sync status) is also written to your Google Sheet. This gives you a spreadsheet backup and lets you use Google Sheets formulas.</p>
                    <p><strong>How to connect:</strong></p>
                    <ol className="list-decimal list-inside space-y-0.5 ml-2">
                      <li>Create a new Google Sheet (or use an existing one)</li>
                      <li>Go to <strong>Extensions → Apps Script</strong></li>
                      <li>Deploy as Web App with &quot;Anyone&quot; access</li>
                      <li>Paste the Web App URL below</li>
                    </ol>
                    <p className="mt-1"><strong>Note:</strong> The dashboard works fully without a Google Sheet. The Sheet is for backup and offline analysis.</p>
                  </div>
                  <div className="space-y-1.5">
                    <Label htmlFor="sheet-url" className="text-xs font-medium">Google Apps Script Web App URL</Label>
                    <Input id="sheet-url" type="url" placeholder="https://script.google.com/macros/s/.../exec" value={googleSheetUrl} onChange={e => setGoogleSheetUrl(e.target.value)} />
                  </div>
                </CardContent>
              </Card>

              {/* Save Settings Button */}
              <div className="flex items-center gap-3">
                <Button onClick={saveSettings} className="bg-slate-900 hover:bg-slate-800">
                  <CheckCircle2 className="w-4 h-4 mr-2" />
                  {savedSettings ? 'Settings Saved!' : 'Save Settings'}
                </Button>
                {savedSettings && <span className="text-sm text-emerald-600">All API keys and URLs saved securely.</span>}
              </div>

              {/* Add Amazon Products */}
              <Card>
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="text-base flex items-center gap-2">
                        <ShoppingCart className="w-5 h-5 text-slate-500" />
                        Add Amazon Products
                      </CardTitle>
                      <CardDescription>Add products by their Amazon ASIN to start monitoring</CardDescription>
                    </div>
                    <Dialog open={addProductOpen} onOpenChange={setAddProductOpen}>
                      <DialogTrigger asChild>
                        <Button size="sm"><Plus className="w-4 h-4 mr-1" /> Add Product</Button>
                      </DialogTrigger>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>Add Amazon Product</DialogTitle>
                          <DialogDescription>Enter the product details to start monitoring its price on Amazon</DialogDescription>
                        </DialogHeader>
                        <div className="space-y-4 py-2">
                          <div className="space-y-1.5">
                            <Label>Product Name</Label>
                            <Input placeholder="e.g. Wireless Bluetooth Earbuds" value={newProductName} onChange={e => setNewProductName(e.target.value)} />
                          </div>
                          <div className="space-y-1.5">
                            <Label>Amazon ASIN</Label>
                            <Input placeholder="e.g. B09V3KXJPB" value={newProductAsin} onChange={e => setNewProductAsin(e.target.value)} />
                            <p className="text-xs text-slate-400">Found in Amazon product URL: amazon.com/dp/<strong>ASIN</strong></p>
                          </div>
                          <div className="grid grid-cols-2 gap-3">
                            <div className="space-y-1.5">
                              <Label>Current Amazon Price ($)</Label>
                              <Input type="number" step="0.01" placeholder="29.99" value={newProductPrice} onChange={e => setNewProductPrice(e.target.value)} />
                            </div>
                            <div className="space-y-1.5">
                              <Label>Profit Margin (%)</Label>
                              <Input type="number" placeholder="30" value={newProductMargin} onChange={e => setNewProductMargin(e.target.value)} />
                              <p className="text-xs text-slate-400">TikTok price = Amazon price + this %</p>
                            </div>
                          </div>
                        </div>
                        <DialogFooter>
                          <Button variant="outline" onClick={() => setAddProductOpen(false)}>Cancel</Button>
                          <Button onClick={handleAddProduct} disabled={addingProduct || !newProductName || !newProductAsin || !newProductPrice}>
                            <Plus className="w-4 h-4 mr-1" />
                            {addingProduct ? 'Adding...' : 'Add Product'}
                          </Button>
                        </DialogFooter>
                      </DialogContent>
                    </Dialog>
                  </div>
                </CardHeader>
                <CardContent>
                  {products.length === 0 ? (
                    <div className="text-center py-8">
                      <ShoppingCart className="w-12 h-12 text-slate-300 mx-auto mb-3" />
                      <h3 className="text-sm font-medium text-slate-600 mb-1">No products added yet</h3>
                      <p className="text-xs text-slate-400 mb-4">Add products manually or click &quot;Load Demo Data&quot; in the header</p>
                    </div>
                  ) : (
                    <ScrollArea className="max-h-[300px]">
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Product Name</TableHead>
                            <TableHead>ASIN</TableHead>
                            <TableHead className="text-right">Amazon $</TableHead>
                            <TableHead className="text-right">Margin</TableHead>
                            <TableHead className="text-right">TikTok $</TableHead>
                            <TableHead className="w-10"></TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {products.map(p => (
                            <TableRow key={p.id}>
                              <TableCell className="font-medium text-sm">{p.name}</TableCell>
                              <TableCell className="text-xs font-mono text-slate-500">{p.asin}</TableCell>
                              <TableCell className="text-right text-sm">${p.currentAmazonPrice.toFixed(2)}</TableCell>
                              <TableCell className="text-right text-sm font-medium">{p.profitMargin.toFixed(0)}%</TableCell>
                              <TableCell className="text-right text-sm font-semibold">${p.tiktokListingPrice.toFixed(2)}</TableCell>
                              <TableCell>
                                <Button variant="ghost" size="sm" className="h-7 w-7 p-0 text-slate-400 hover:text-red-500" onClick={() => handleDeleteProduct(p.id)}>
                                  <Trash2 className="w-3.5 h-3.5" />
                                </Button>
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </ScrollArea>
                  )}
                </CardContent>
              </Card>

            </div>
          </TabsContent>

          {/* ===== DASHBOARD TAB ===== */}
          <TabsContent value="dashboard">
            {totalProducts === 0 ? (
              <Card>
                <CardContent className="p-12 text-center">
                  <Database className="w-16 h-16 text-slate-300 mx-auto mb-4" />
                  <h2 className="text-xl font-semibold text-slate-700 mb-2">No Products Yet</h2>
                  <p className="text-slate-500 mb-6 max-w-md mx-auto">
                    Go to <strong>Setup</strong> tab to add your Amazon products, or click <strong>Load Demo Data</strong> to test the dashboard with sample data.
                  </p>
                  <div className="flex gap-3 justify-center">
                    <Button variant="outline" onClick={() => setActiveTab('setup')}><Settings className="w-4 h-4 mr-2" />Go to Setup</Button>
                    <Button onClick={handleSeed} disabled={seeding}><Database className="w-4 h-4 mr-2" />Load Demo Data</Button>
                  </div>
                </CardContent>
              </Card>
            ) : (
              <div className="grid gap-6 lg:grid-cols-3">
                <div className="lg:col-span-2">
                  <Card>
                    <CardHeader className="pb-3">
                      <CardTitle className="text-base">Product Overview</CardTitle>
                      <CardDescription>Current status of all monitored products</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <ScrollArea className="max-h-[420px]">
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>Product</TableHead>
                              <TableHead className="text-right">Amazon $</TableHead>
                              <TableHead className="text-right">TikTok $</TableHead>
                              <TableHead className="text-right">Margin</TableHead>
                              <TableHead>Status</TableHead>
                              <TableHead>Sync</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {products.map(p => (
                              <TableRow key={p.id}>
                                <TableCell className="font-medium max-w-[160px] truncate">{p.name}</TableCell>
                                <TableCell className="text-right">${p.currentAmazonPrice.toFixed(2)}</TableCell>
                                <TableCell className="text-right font-medium">${p.tiktokListingPrice.toFixed(2)}</TableCell>
                                <TableCell className={`text-right font-medium ${p.profitMargin < 20 ? 'text-red-600' : p.profitMargin < 35 ? 'text-amber-600' : 'text-emerald-600'}`}>
                                  {p.profitMargin.toFixed(1)}%
                                </TableCell>
                                <TableCell>
                                  {p.stockStatus === 'IN STOCK'
                                    ? <Badge variant="outline" className="text-xs bg-emerald-50 text-emerald-700 hover:bg-emerald-50"><PackageCheck className="w-3 h-3 mr-1" />In Stock</Badge>
                                    : <Badge variant="outline" className="text-xs bg-red-50 text-red-700 hover:bg-red-50"><PackageX className="w-3 h-3 mr-1" />Out</Badge>
                                  }
                                </TableCell>
                                <TableCell>{getStatusBadge(p.syncStatus)}</TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </ScrollArea>
                    </CardContent>
                  </Card>
                </div>
                <div>
                  <Card>
                    <CardHeader className="pb-3">
                      <div className="flex items-center justify-between">
                        <CardTitle className="text-base">Recent Alerts</CardTitle>
                        {pendingAlerts > 0 && <Badge className="bg-red-500 hover:bg-red-500 text-white text-xs">{pendingAlerts} new</Badge>}
                      </div>
                    </CardHeader>
                    <CardContent>
                      {alerts.length === 0 ? (
                        <p className="text-sm text-slate-400 text-center py-8">No pending alerts. Run a price check to detect changes.</p>
                      ) : (
                        <ScrollArea className="max-h-[380px]">
                          <div className="space-y-3">
                            {alerts.slice(0, 8).map(a => (
                              <div key={a.id} className="p-3 rounded-lg border border-slate-200 bg-white">
                                <div className="flex items-start justify-between gap-2 mb-2">
                                  {getAlertBadge(a.alertType)}
                                  <span className="text-[10px] text-slate-400 whitespace-nowrap">{new Date(a.createdAt).toLocaleTimeString()}</span>
                                </div>
                                <p className="text-xs text-slate-600 mb-2">{a.product.name}</p>
                                <p className="text-xs text-slate-500 mb-3">{a.message}</p>
                                <div className="flex gap-2">
                                  <Button size="sm" className="h-7 text-xs flex-1 bg-emerald-600 hover:bg-emerald-700" onClick={() => openDialog(a, 'ACCEPT')}>
                                    <CheckCircle2 className="w-3 h-3 mr-1" /> Accept
                                  </Button>
                                  <Button size="sm" variant="outline" className="h-7 text-xs flex-1" onClick={() => openDialog(a, 'REJECT')}>
                                    <XCircle className="w-3 h-3 mr-1" /> Reject
                                  </Button>
                                </div>
                              </div>
                            ))}
                          </div>
                        </ScrollArea>
                      )}
                    </CardContent>
                  </Card>
                </div>
              </div>
            )}
          </TabsContent>

          {/* ===== ALERTS TAB ===== */}
          <TabsContent value="alerts">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Pending Alerts</CardTitle>
                    <CardDescription>Review and approve/reject changes before they sync to TikTok Shop</CardDescription>
                  </div>
                  {pendingAlerts > 0 && (
                    <Button variant="outline" size="sm" onClick={handleSimulate} disabled={simulating}>
                      <RefreshCw className="w-4 h-4 mr-1" /> Re-check Prices
                    </Button>
                  )}
                </div>
              </CardHeader>
              <CardContent>
                {alerts.length === 0 ? (
                  <div className="text-center py-12">
                    <Bell className="w-12 h-12 text-slate-300 mx-auto mb-3" />
                    <h3 className="text-lg font-medium text-slate-600 mb-1">All Clear</h3>
                    <p className="text-sm text-slate-400">No pending alerts. Click &quot;Simulate Price Check&quot; to test the monitoring system.</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {alerts.map(a => (
                      <div key={a.id} className="border border-slate-200 rounded-lg p-4 bg-white hover:shadow-sm transition-shadow">
                        <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-2">
                              {getAlertBadge(a.alertType)}
                              <span className="text-xs text-slate-400">{new Date(a.createdAt).toLocaleString()}</span>
                            </div>
                            <h4 className="font-semibold text-slate-800 mb-1">{a.product.name}</h4>
                            <p className="text-sm text-slate-600 mb-2">{a.message}</p>
                            <div className="flex items-center gap-4 text-xs text-slate-500">
                              <span>ASIN: {a.product.asin}</span>
                              {a.alertType.includes('PRICE') && (
                                <>
                                  <span className="flex items-center gap-1"><ArrowRight className="w-3 h-3" />${a.oldValue.toFixed(2)} → ${a.newValue.toFixed(2)}</span>
                                  {a.oldMargin !== undefined && a.newMargin !== undefined && (
                                    <span className={a.newMargin < a.oldMargin ? 'text-red-600' : 'text-emerald-600'}>
                                      Margin: {a.oldMargin.toFixed(1)}% → {a.newMargin.toFixed(1)}%
                                    </span>
                                  )}
                                </>
                              )}
                            </div>
                          </div>
                          <div className="flex sm:flex-col gap-2">
                            <Button size="sm" className="bg-emerald-600 hover:bg-emerald-700" onClick={() => openDialog(a, 'ACCEPT')}>
                              <CheckCircle2 className="w-4 h-4 mr-1" /> Accept
                            </Button>
                            <Button size="sm" variant="outline" onClick={() => openDialog(a, 'REJECT')}>
                              <XCircle className="w-4 h-4 mr-1" /> Reject
                            </Button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* ===== PRODUCTS TAB ===== */}
          <TabsContent value="products">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Product Master Database</CardTitle>
                    <CardDescription>All monitored products with live pricing and sync status</CardDescription>
                  </div>
                  <Button size="sm" onClick={() => setAddProductOpen(true)}><Plus className="w-4 h-4 mr-1" /> Add Product</Button>
                </div>
              </CardHeader>
              <CardContent>
                <ScrollArea className="max-h-[600px]">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Product</TableHead>
                        <TableHead>ASIN</TableHead>
                        <TableHead className="text-right">Original $</TableHead>
                        <TableHead className="text-right">Current $</TableHead>
                        <TableHead>Change</TableHead>
                        <TableHead className="text-right">TikTok $</TableHead>
                        <TableHead className="text-right">Margin</TableHead>
                        <TableHead>Stock</TableHead>
                        <TableHead>Sync</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {products.map(p => (
                        <TableRow key={p.id}>
                          <TableCell className="font-medium max-w-[140px] truncate">{p.name}</TableCell>
                          <TableCell className="text-xs font-mono text-slate-500">{p.asin}</TableCell>
                          <TableCell className="text-right">${p.originalAmazonPrice.toFixed(2)}</TableCell>
                          <TableCell className="text-right font-medium">${p.currentAmazonPrice.toFixed(2)}</TableCell>
                          <TableCell>
                            {p.priceChangeStatus === 'UP' && <Badge variant="outline" className="text-xs bg-red-50 text-red-700 hover:bg-red-50"><TrendingUp className="w-3 h-3 mr-1" />UP</Badge>}
                            {p.priceChangeStatus === 'DOWN' && <Badge variant="outline" className="text-xs bg-emerald-50 text-emerald-700 hover:bg-emerald-50"><TrendingDown className="w-3 h-3 mr-1" />DOWN</Badge>}
                            {p.priceChangeStatus === 'NO CHANGE' && <span className="text-xs text-slate-400">—</span>}
                          </TableCell>
                          <TableCell className="text-right font-semibold">${p.tiktokListingPrice.toFixed(2)}</TableCell>
                          <TableCell className={`text-right font-semibold ${p.profitMargin < 20 ? 'text-red-600' : p.profitMargin < 35 ? 'text-amber-600' : 'text-emerald-600'}`}>
                            {p.profitMargin.toFixed(1)}%
                          </TableCell>
                          <TableCell>
                            {p.stockStatus === 'IN STOCK'
                              ? <Badge variant="outline" className="text-xs bg-emerald-50 text-emerald-700 hover:bg-emerald-50">In Stock</Badge>
                              : <Badge variant="outline" className="text-xs bg-red-50 text-red-700 hover:bg-red-50">Out</Badge>
                            }
                          </TableCell>
                          <TableCell>{getStatusBadge(p.syncStatus)}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>

          {/* ===== LOGS TAB ===== */}
          <TabsContent value="logs">
            <Card>
              <CardHeader>
                <CardTitle>System Logs</CardTitle>
                <CardDescription>API calls, sync actions, and error records</CardDescription>
              </CardHeader>
              <CardContent>
                <ScrollArea className="max-h-[600px]">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Time</TableHead>
                        <TableHead>Severity</TableHead>
                        <TableHead>Action</TableHead>
                        <TableHead>Product</TableHead>
                        <TableHead>Detail</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {logs.map(l => (
                        <TableRow key={l.id}>
                          <TableCell className="text-xs text-slate-500 whitespace-nowrap">{new Date(l.createdAt).toLocaleString()}</TableCell>
                          <TableCell>{getSeverityBadge(l.severity)}</TableCell>
                          <TableCell className="text-xs font-medium">{l.action}</TableCell>
                          <TableCell className="text-xs text-slate-500">{l.product?.name || '—'}</TableCell>
                          <TableCell className="text-xs text-slate-600 max-w-[300px] truncate">{l.detail}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>

      {/* Confirm Dialog */}
      <AlertDialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>
              {dialogAction === 'ACCEPT' ? 'Approve TikTok Sync?' : 'Reject This Change?'}
            </AlertDialogTitle>
            <AlertDialogDescription asChild>
              <div>
                {selectedAlert && (
                  <div className="space-y-2 text-sm">
                    <p><strong>Product:</strong> {selectedAlert.product.name}</p>
                    <p><strong>Alert:</strong> {selectedAlert.message}</p>
                    {dialogAction === 'ACCEPT' ? (
                      <p className="text-emerald-700">This will update the TikTok Shop listing price and/or inventory to match the new Amazon data.</p>
                    ) : (
                      <p className="text-red-700">The TikTok listing will remain unchanged. This rejection will be logged.</p>
                    )}
                  </div>
                )}
              </div>
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => selectedAlert && handleSync(selectedAlert.id, dialogAction)}
              className={dialogAction === 'ACCEPT' ? 'bg-emerald-600 hover:bg-emerald-700' : 'bg-red-600 hover:bg-red-700'}
            >
              {dialogAction === 'ACCEPT' ? 'Yes, Approve' : 'Yes, Reject'}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}
