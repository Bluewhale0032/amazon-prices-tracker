#!/usr/bin/env python3
"""Generate Project Brief PDF: Amazon Price Monitoring & TikTok Shop Auto-Sync System"""

import os, sys, hashlib
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import inch, mm
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_LEFT, TA_CENTER, TA_JUSTIFY
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
    Image, KeepTogether, HRFlowable, PageBreak
)
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfbase.pdfmetrics import registerFontFamily

# ── Paths ──
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
PDF_SKILL_DIR = os.path.join(os.path.dirname(SCRIPT_DIR), 'skills', 'pdf')
FONT_DIR = '/usr/share/fonts'
OUTPUT_PATH = os.path.join(os.path.dirname(SCRIPT_DIR), 'download', 'amazon-tiktok-sync-project-brief.pdf')
DIAGRAM_PATH = os.path.join(SCRIPT_DIR, 'arch_diagram.png')

# ── Register Fonts ──
pdfmetrics.registerFont(TTFont('FreeSerif', f'{FONT_DIR}/truetype/freefont/FreeSerif.ttf'))
pdfmetrics.registerFont(TTFont('FreeSerif-Bold', f'{FONT_DIR}/truetype/freefont/FreeSerifBold.ttf'))
pdfmetrics.registerFont(TTFont('FreeSerif-Italic', f'{FONT_DIR}/truetype/freefont/FreeSerifItalic.ttf'))
pdfmetrics.registerFont(TTFont('FreeSerif-BoldItalic', f'{FONT_DIR}/truetype/freefont/FreeSerifBoldItalic.ttf'))
pdfmetrics.registerFont(TTFont('NotoSerifSC', f'{FONT_DIR}/truetype/noto-serif-sc/NotoSerifSC-Regular.ttf'))
pdfmetrics.registerFont(TTFont('NotoSerifSC-Bold', f'{FONT_DIR}/truetype/noto-serif-sc/NotoSerifSC-Bold.ttf'))
# Noto Sans SC is variable font - skip if not available as static
_noto_sans_sc_path = f'{FONT_DIR}/truetype/chinese/NotoSansSC-Regular.ttf'
if os.path.exists(_noto_sans_sc_path):
    pdfmetrics.registerFont(TTFont('Noto Sans SC', _noto_sans_sc_path))
    pdfmetrics.registerFont(TTFont('Noto Sans SC Bold', _noto_sans_sc_path))
    registerFontFamily('Noto Sans SC', normal='Noto Sans SC', bold='Noto Sans SC Bold')
pdfmetrics.registerFont(TTFont('DejaVuSans', f'{FONT_DIR}/truetype/dejavu/DejaVuSansMono.ttf'))

registerFontFamily('FreeSerif', normal='FreeSerif', bold='FreeSerif-Bold', italic='FreeSerif-Italic', boldItalic='FreeSerif-BoldItalic')
registerFontFamily('NotoSerifSC', normal='NotoSerifSC', bold='NotoSerifSC-Bold')
registerFontFamily('Noto Sans SC', normal='Noto Sans SC', bold='Noto Sans SC Bold')

# ── Install font fallback ──
sys.path.insert(0, os.path.join(PDF_SKILL_DIR, 'scripts'))
from pdf import install_font_fallback
install_font_fallback()

# ── Cascade Palette ──
PAGE_BG       = colors.HexColor('#f0f0f1')
SECTION_BG    = colors.HexColor('#eaebeb')
CARD_BG       = colors.HexColor('#eaeced')
TABLE_STRIPE  = colors.HexColor('#eff0f0')
HEADER_FILL   = colors.HexColor('#3f5763')
COVER_BLOCK   = colors.HexColor('#475a64')
BORDER        = colors.HexColor('#bcccd4')
ICON          = colors.HexColor('#51798d')
ACCENT        = colors.HexColor('#1c6d96')
ACCENT_2      = colors.HexColor('#bc2f46')
TEXT_PRIMARY   = colors.HexColor('#232627')
TEXT_MUTED     = colors.HexColor('#7b8285')
SEM_SUCCESS   = colors.HexColor('#428759')
SEM_WARNING   = colors.HexColor('#a58649')
SEM_ERROR     = colors.HexColor('#a1463d')
SEM_INFO      = colors.HexColor('#466787')

# ── Page setup ──
PAGE_W, PAGE_H = A4
MARGIN = 0.9 * inch
CONTENT_W = PAGE_W - 2 * MARGIN

# ── Styles ──
sH1 = ParagraphStyle('H1', fontName='FreeSerif-Bold', fontSize=18, leading=24,
    textColor=HEADER_FILL, spaceAfter=10, spaceBefore=18)
sH2 = ParagraphStyle('H2', fontName='FreeSerif-Bold', fontSize=13, leading=18,
    textColor=ACCENT, spaceAfter=6, spaceBefore=12)
sBody = ParagraphStyle('Body', fontName='FreeSerif', fontSize=10.5, leading=17,
    textColor=TEXT_PRIMARY, alignment=TA_JUSTIFY, spaceAfter=6)
sBodyLeft = ParagraphStyle('BodyLeft', fontName='FreeSerif', fontSize=10.5, leading=17,
    textColor=TEXT_PRIMARY, alignment=TA_LEFT, spaceAfter=4)
sBullet = ParagraphStyle('Bullet', fontName='FreeSerif', fontSize=10.5, leading=17,
    textColor=TEXT_PRIMARY, alignment=TA_LEFT, spaceAfter=3, leftIndent=18, bulletIndent=6)
sCaption = ParagraphStyle('Caption', fontName='FreeSerif-Italic', fontSize=9, leading=13,
    textColor=TEXT_MUTED, alignment=TA_CENTER, spaceAfter=8, spaceBefore=4)
sTableHeader = ParagraphStyle('TH', fontName='FreeSerif-Bold', fontSize=9.5, leading=13,
    textColor=colors.white, alignment=TA_LEFT)
sTableCell = ParagraphStyle('TC', fontName='FreeSerif', fontSize=9.5, leading=13,
    textColor=TEXT_PRIMARY, alignment=TA_LEFT, wordWrap='CJK')
sTableCellBold = ParagraphStyle('TCB', fontName='FreeSerif-Bold', fontSize=9.5, leading=13,
    textColor=TEXT_PRIMARY, alignment=TA_LEFT)
sNote = ParagraphStyle('Note', fontName='FreeSerif-Italic', fontSize=9.5, leading=14,
    textColor=TEXT_MUTED, alignment=TA_LEFT, spaceAfter=4, leftIndent=18)

# ── Helper: Section HR ──
def section_hr():
    return HRFlowable(width='100%', thickness=0.5, color=BORDER, spaceAfter=8, spaceBefore=4)

# ── Helper: Safe table ──
def safe_table(header, rows, col_widths=None):
    """Build a table with Paragraph-wrapped cells."""
    data = []
    # Header
    data.append([Paragraph(str(c), sTableHeader) for c in header])
    # Rows
    for row in rows:
        data.append([Paragraph(str(c), sTableCell) for c in row])

    if col_widths is None:
        n = len(header)
        col_widths = [CONTENT_W / n] * n

    tbl = Table(data, colWidths=col_widths, repeatRows=1)
    style_cmds = [
        ('BACKGROUND', (0, 0), (-1, 0), HEADER_FILL),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
        ('FONTNAME', (0, 0), (-1, 0), 'FreeSerif-Bold'),
        ('FONTSIZE', (0, 0), (-1, 0), 9.5),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 8),
        ('TOPPADDING', (0, 0), (-1, 0), 8),
        ('LEFTPADDING', (0, 0), (-1, -1), 8),
        ('RIGHTPADDING', (0, 0), (-1, -1), 8),
        ('TOPPADDING', (0, 1), (-1, -1), 6),
        ('BOTTOMPADDING', (0, 1), (-1, -1), 6),
        ('GRID', (0, 0), (-1, -1), 0.5, BORDER),
        ('VALIGN', (0, 0), (-1, -1), 'TOP'),
    ]
    # Alternate row colors
    for i in range(1, len(data)):
        bg = colors.white if i % 2 == 1 else TABLE_STRIPE
        style_cmds.append(('BACKGROUND', (0, i), (-1, i), bg))

    tbl.setStyle(TableStyle(style_cmds))
    return tbl

# ── Build Story ──
story = []

# ── Section 1: Objective ──
story.append(Paragraph('<b>1. Objective</b>', sH1))
story.append(section_hr())
story.append(Paragraph(
    'This project brief defines the requirements for an automated system that continuously monitors '
    'Amazon product prices and stock availability, updates a Google Sheet in real time, alerts the operator '
    'when a price or stock change is detected, and provides a web-based dashboard where the operator can '
    'approve or reject syncing each change to their TikTok Shop listing. The system is designed to eliminate '
    'manual price-checking workflows, reduce the risk of selling out-of-stock items, and ensure that TikTok '
    'Shop pricing always reflects the latest Amazon cost basis plus the desired profit margin.',
    sBody))
story.append(Paragraph(
    'The core value proposition is a closed-loop pipeline: Amazon data feeds into a master database, '
    'changes are surfaced through an alert dashboard with human-in-the-loop approval, and approved changes '
    'are automatically pushed to TikTok Shop. This architecture ensures that no price update reaches the '
    'TikTok storefront without explicit operator consent, while out-of-stock events are handled automatically '
    'to prevent overselling. The system will run on Google Apps Script as the orchestration layer, leveraging '
    'time-based triggers for scheduled monitoring and the Keepa and TikTok Shop APIs for data retrieval and sync.',
    sBody))
story.append(Spacer(1, 8))

# ── Section 2: System Architecture ──
story.append(Paragraph('<b>2. System Architecture</b>', sH1))
story.append(section_hr())
story.append(Paragraph(
    'The system consists of five interconnected components that form a unidirectional data pipeline with '
    'a human approval gate. The Keepa API periodically fetches Amazon price and stock data, which is written '
    'to the Google Sheet master database. When changes are detected, the Alert Dashboard surfaces them for '
    'operator review. Approved changes are pushed to TikTok Shop via its Partner API, while all actions and '
    'errors are logged to a separate Logs sheet. Email notifications are sent for every detected change and '
    'for any API failures.',
    sBody))
story.append(Spacer(1, 6))

# Architecture diagram
if os.path.exists(DIAGRAM_PATH):
    from reportlab.platypus import Image as RLImage
    img = RLImage(DIAGRAM_PATH)
    orig_w, orig_h = img.drawWidth, img.drawHeight
    max_w = CONTENT_W
    max_h = PAGE_H * 0.35
    ratio_w = max_w / orig_w if orig_w > max_w else 1.0
    ratio_h = max_h / orig_h if orig_h > max_h else 1.0
    ratio = min(ratio_w, ratio_h)
    img.drawWidth = orig_w * ratio
    img.drawHeight = orig_h * ratio
    story.append(KeepTogether([img, Paragraph('Figure 1: System Architecture - Data Flow Overview', sCaption)]))

story.append(Spacer(1, 8))

# ── Section 3: System Components ──
story.append(Paragraph('<b>3. System Components</b>', sH1))
story.append(section_hr())

# 3.1 Google Sheet
story.append(Paragraph('<b>3.1 Google Sheet (Master Database)</b>', sH2))
story.append(Paragraph(
    'The Google Sheet serves as the single source of truth for all product data. It stores both the original '
    'and current Amazon prices, the calculated profit margin, the current TikTok listing price, and the sync '
    'status of each product. Every column is updated automatically by the Apps Script backend, except for the '
    '"Notes" column which logs a timestamped record of all actions taken on each row. The sheet must support '
    'at least 500 product rows without performance degradation.',
    sBody))
story.append(Spacer(1, 4))

sheet_cols = [
    ('Product Name', 'Name of the product'),
    ('ASIN', 'Amazon Standard Identification Number'),
    ('Original Amazon Price', 'Price when product was first listed'),
    ('Current Amazon Price', 'Auto-updated live price'),
    ('Price Change Status', 'UP / DOWN / NO CHANGE'),
    ('TikTok Listing Price', 'Price currently live on TikTok Shop'),
    ('Profit Margin (%)', 'Calculated automatically'),
    ('Stock Status', 'IN STOCK / OUT OF STOCK'),
    ('Last Updated', 'Timestamp of last check'),
    ('Sync Status', 'PENDING / ACCEPTED / REJECTED / FAILED'),
    ('Notes', 'Log of actions taken'),
]
sheet_data = [[c[0], c[1]] for c in sheet_cols]
sheet_widths = [CONTENT_W * 0.35, CONTENT_W * 0.65]
story.append(safe_table(['Column', 'Description'], sheet_data, sheet_widths))
story.append(Spacer(1, 8))

# 3.2 Amazon Price Monitoring
story.append(Paragraph('<b>3.2 Amazon Price Monitoring</b>', sH2))
story.append(Paragraph(
    'The system uses the Keepa API (or a similar Amazon price-tracking service) as the primary data source '
    'for price and stock information. A scheduled job runs every 6 to 12 hours, iterating through all ASINs '
    'in the Google Sheet and fetching the current price and availability. When a price change is detected, '
    'the system updates the "Current Amazon Price," "Price Change Status," and "Stock Status" columns, and '
    'recalculates the profit margin. The comparison logic accounts for minor price fluctuations by applying '
    'a configurable threshold (default: $0.01) to avoid triggering alerts on negligible changes.',
    sBody))
story.append(Spacer(1, 8))

# 3.3 Alert Dashboard
story.append(Paragraph('<b>3.3 Alert Dashboard</b>', sH2))
story.append(Paragraph(
    'The Alert Dashboard is a Google Apps Script Web App that provides a real-time view of all products '
    'with pending price or stock changes. Each alert displays the product name, the old and new prices, the '
    'updated profit margin, and two action buttons: Accept and Reject. For out-of-stock events, the dashboard '
    'shows a prominent red "OUT OF STOCK" badge. The dashboard refreshes automatically when new alerts arrive '
    'and supports bulk operations for accepting or rejecting multiple changes at once.',
    sBody))
story.append(Spacer(1, 4))
story.append(Paragraph('<b>Example alert messages:</b>', sBodyLeft))
story.append(Paragraph('"Product X price increased from $5 to $6. Profit margin dropped from 40% to 20%. Approve TikTok update?"', sNote))
story.append(Paragraph('"Product Y price decreased from $8 to $7. New profit margin: 35%. Approve TikTok update?"', sNote))
story.append(Paragraph('"Product Z is now OUT OF STOCK on Amazon. Set TikTok inventory to 0?"', sNote))
story.append(Spacer(1, 8))

# 3.4 TikTok Shop API Integration
story.append(Paragraph('<b>3.4 TikTok Shop API Integration</b>', sH2))
story.append(Paragraph(
    'The TikTok Shop Partner API (Open Platform) is used to sync approved price and inventory changes. '
    'When the operator clicks Accept on an alert, the system calculates the new TikTok listing price by '
    'applying the configured profit margin to the new Amazon price, then pushes the update to TikTok Shop. '
    'For out-of-stock items, the system automatically sets TikTok inventory to zero without requiring approval. '
    'When a previously out-of-stock item returns to stock, the system restores the inventory level. All actions '
    'are logged with timestamps in the Notes column. If the operator clicks Reject, no change is made to the '
    'TikTok listing and the rejection is logged.',
    sBody))
story.append(Spacer(1, 8))

# 3.5 Automation & Notifications
story.append(Paragraph('<b>3.5 Automation and Notifications</b>', sH2))
story.append(Paragraph(
    'Google Apps Script time-based triggers execute the price-check function every 6 to 12 hours. The trigger '
    'frequency can be adjusted in the Apps Script dashboard without code changes. When a price or stock change '
    'is detected, the system sends an email notification to the operator with a summary of the change and a '
    'direct link to the Alert Dashboard. Email alerts are also sent when the Keepa API call fails or when a '
    'TikTok Shop API update returns an error. The dashboard reflects new alerts in near-real-time by polling '
    'the Google Sheet on each page load.',
    sBody))
story.append(Spacer(1, 8))

# 3.6 Error Handling & Logging
story.append(Paragraph('<b>3.6 Error Handling and Logging</b>', sH2))
story.append(Paragraph(
    'A dedicated "Logs" sheet records every API call, data update, and error event with a timestamp, severity '
    'level, and detailed message. If the Keepa API call fails (e.g., rate limit exceeded, invalid ASIN, network '
    'timeout), the system sends an email alert and skips the affected product. If the TikTok API update fails, '
    'the corresponding row in the master sheet is marked as "FAILED" and the operator is notified. The system '
    'implements exponential backoff for API retries (max 3 attempts) and gracefully handles partial failures by '
    'continuing to process remaining products in the queue.',
    sBody))
story.append(Spacer(1, 10))

# ── Section 4: Technical Stack ──
story.append(Paragraph('<b>4. Technical Stack</b>', sH1))
story.append(section_hr())
story.append(Paragraph(
    'The technology choices prioritize simplicity, low cost, and ease of maintenance. Google Sheets provides '
    'a familiar spreadsheet interface with built-in collaboration features, while Google Apps Script offers a '
    'zero-infrastructure backend with native integration to Sheets, Gmail, and time-based triggers. The Keepa '
    'and TikTok Shop APIs are accessed via standard HTTP requests from Apps Script.',
    sBody))
story.append(Spacer(1, 4))

stack_data = [
    ['Google Sheets', 'Data storage and collaboration'],
    ['Google Apps Script', 'Backend automation, scheduling, and logic'],
    ['Keepa API', 'Amazon price and stock data retrieval'],
    ['TikTok Shop Partner API', 'Price and inventory synchronization'],
    ['Google Apps Script Web App', 'Dashboard frontend (HTML/CSS/JS)'],
]
stack_widths = [CONTENT_W * 0.40, CONTENT_W * 0.60]
story.append(safe_table(['Technology', 'Role'], stack_data, stack_widths))
story.append(Spacer(1, 10))

# ── Section 5: Deliverables ──
story.append(Paragraph('<b>5. Deliverables</b>', sH1))
story.append(section_hr())
story.append(Paragraph(
    'The following deliverables are expected upon project completion. Each deliverable is designed to be '
    'self-contained and immediately usable, with minimal configuration required from the operator. The '
    'documentation deliverable covers API key setup, dashboard usage, and troubleshooting guidance.',
    sBody))
story.append(Spacer(1, 4))

deliverables = [
    ('1', 'Google Sheet template with all required columns, formulas, and conditional formatting.'),
    ('2', 'Google Apps Script code for Keepa API integration and automated price-check scheduling.'),
    ('3', 'Dashboard web app (HTML/CSS/JS inside Apps Script) with Accept/Reject action buttons.'),
    ('4', 'TikTok Shop API integration code for price and inventory updates.'),
    ('5', 'Time-based trigger configuration for automatic scheduled checks (6-12 hour intervals).'),
    ('6', 'Setup documentation covering API key/credential configuration and dashboard usage guide.'),
]
del_widths = [CONTENT_W * 0.07, CONTENT_W * 0.93]
story.append(safe_table(['#', 'Deliverable'], deliverables, del_widths))
story.append(Spacer(1, 10))

# ── Section 6: Client Requirements ──
story.append(Paragraph('<b>6. Client Requirements</b>', sH1))
story.append(section_hr())
story.append(Paragraph(
    'The following requirements are provided by the client and represent non-negotiable constraints for the '
    'system design. The client will supply all API credentials; no third-party authentication setup is required '
    'from the developer. All pricing logic must respect the profit margin calculation at all times.',
    sBody))
story.append(Spacer(1, 4))

req_data = [
    ['Credentials', 'Client will provide the Keepa API key and TikTok Shop Developer/Partner API credentials.'],
    ['Margin Rule', 'All TikTok price updates must include the profit margin calculation. The Amazon price must never be copied directly to TikTok.'],
    ['Auto Out-of-Stock', 'Out-of-stock status must sync to TikTok as zero inventory automatically, without requiring operator approval.'],
    ['Approval Gate', 'Price changes (up or down) must always go through the Accept/Reject approval step before updating TikTok.'],
]
req_widths = [CONTENT_W * 0.22, CONTENT_W * 0.78]
story.append(safe_table(['Requirement', 'Description'], req_data, req_widths))

# ── Build Body PDF ──
doc = SimpleDocTemplate(
    OUTPUT_PATH,
    pagesize=A4,
    leftMargin=MARGIN,
    rightMargin=MARGIN,
    topMargin=MARGIN,
    bottomMargin=MARGIN,
    title='Amazon Price Monitoring & TikTok Shop Auto-Sync System - Project Brief',
    author='Z.ai',
    creator='Z.ai',
    subject='Technical Project Brief',
)

# Add page number footer
def add_page_number(canvas, doc):
    canvas.saveState()
    canvas.setFont('FreeSerif', 8)
    canvas.setFillColor(TEXT_MUTED)
    page_num = canvas.getPageNumber()
    if page_num > 0:
        canvas.drawCentredString(PAGE_W / 2, 0.5 * inch, f'{page_num}')
    canvas.restoreState()

doc.build(story, onFirstPage=add_page_number, onLaterPages=add_page_number)
print(f'Body PDF generated: {OUTPUT_PATH}')
