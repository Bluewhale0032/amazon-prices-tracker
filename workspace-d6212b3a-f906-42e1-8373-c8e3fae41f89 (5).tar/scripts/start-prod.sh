#!/bin/bash
cd /home/z/my-project
export NODE_ENV=production
while true; do
    node .next/standalone/server.js
    echo "Server crashed, restarting in 3s..."
    sleep 3
done
