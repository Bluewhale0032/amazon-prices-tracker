#!/bin/bash
# Keep-alive script that restarts Next.js production server if it crashes
cd /home/z/my-project

while true; do
    echo "[$(date)] Starting Next.js production server..."
    NODE_ENV=production node .next/standalone/server.js
    EXIT_CODE=$?
    echo "[$(date)] Server exited with code $EXIT_CODE, restarting in 3 seconds..."
    sleep 3
done
