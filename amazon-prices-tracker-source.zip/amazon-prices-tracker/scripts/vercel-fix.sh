#!/bin/bash
# ================================================================
# Vercel Deployment Fix Script
# ================================================================
# ye script un changes ko apply karega jo Vercel deployment ke liye
# zaroori hain. GitHub pe ye files update karni hain:
#
# 1. next.config.ts - "standalone" hatana
# 2. prisma/schema.prisma - SQLite se PostgreSQL
# 3. package.json - build command aur postinstall
# 4. .env.example - PostgreSQL URL example
# ================================================================

echo "🔧 Vercel Deployment Fix"
echo "========================"
echo ""
echo "Ye changes GitHub pe karne hain:"
echo ""

echo "1️⃣  next.config.ts - ye content rakhna:"
echo "---"
cat << 'NEXTCONFIG'
import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  /* config options here */
  typescript: {
    ignoreBuildErrors: true,
  },
  reactStrictMode: false,
};

export default nextConfig;
NEXTCONFIG

echo ""
echo "2️⃣  prisma/schema.prisma - pehla section ye rakhna:"
echo "---"
cat << 'PRISMA'
generator client {
  provider = "prisma-client-js"
}

datasource db {
  provider = "postgresql"
  url      = env("DATABASE_URL")
}
PRISMA

echo ""
echo "3️⃣  package.json - scripts section ye rakhna:"
echo "---"
cat << 'SCRIPTS'
"scripts": {
    "dev": "next dev -p 3000",
    "build": "prisma generate && next build",
    "start": "next start",
    "lint": "eslint .",
    "postinstall": "prisma generate",
    "db:push": "prisma db push",
    "db:generate": "prisma generate",
    "db:migrate": "prisma migrate dev",
    "db:migrate:deploy": "prisma migrate deploy",
    "db:reset": "prisma migrate reset"
}
SCRIPTS

echo ""
echo "4️⃣  Vercel Dashboard pe Environment Variables:"
echo "---"
echo "DATABASE_URL = postgresql://user:password@host:5432/database?sslmode=require"
echo ""
echo "(Vercel Postgres use karein - wo khud set kar dega)"
echo ""
echo "5️⃣  Build Command (Vercel Settings):"
echo "---"
echo "prisma migrate deploy && prisma generate && next build"
echo ""
echo "========================"
echo "✅ Ye changes karne ke baad Vercel pe redeploy karein"
